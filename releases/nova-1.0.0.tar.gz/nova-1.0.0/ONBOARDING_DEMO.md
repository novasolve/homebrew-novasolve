# Nova Onboarding Demo: Email Validation Regex Fix

## Overview

We've implemented an email validation regex fix as Nova's primary onboarding demo. This demo showcases Nova's ability to:
- Understand failing test intent
- Fix complex regex patterns
- Complete the fix in under 60 seconds

## Why Email Validation?

Based on our analysis, the email validation test is the ideal onboarding demo because:

1. **High Impact, Low Complexity**: Single-line fix that solves a real problem
2. **Demonstrates Intelligence**: Regex adjustments require understanding, not just pattern matching
3. **Common Use Case**: Every developer has dealt with email validation edge cases
4. **Quick & Reliable**: Completes in ~6 seconds with consistent results

## The Demo Flow

```
1. Show failing test for "user@mail.company.co.uk"
2. Nova analyzes the regex pattern is too strict (only allows 2-4 char TLDs)
3. Nova fixes the pattern to handle:
   - Multiple subdomains (mail.company.co.uk)
   - Longer TLDs (.museum, .systems)
4. Tests pass - all green! ✅
```

## Implementation

The demo is integrated into Nova's onboarding flow:
- **Location**: `nova/cli/onboarding.py` - `_beat_demo()` method
- **Test Files**: Created in a temp directory during demo
- **Fix Applied**: Updates regex from `[A-Za-z]{2,4}$` to `(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$`

## Running the Demo

```bash
# Run the standalone demo
./run_demo.py

# Or run Nova normally (demo runs on first launch)
nova
```

## The Fix in Detail

**Before (Too Strict):**
```python
pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}$'
```

**After (Handles Edge Cases):**
```python
pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$'
```

The fix adds:
- `(\.[A-Za-z0-9-]+)*` - Allows multiple subdomain levels
- `{2,}` instead of `{2,4}` - Allows TLDs longer than 4 characters

## Impact

This demo delivers the "wow" moment within seconds:
- User sees a realistic bug they've likely encountered
- Nova fixes it intelligently, not just mechanically
- Creates immediate trust in Nova's capabilities

Perfect for turning first-time users into instant fans! 🚀 