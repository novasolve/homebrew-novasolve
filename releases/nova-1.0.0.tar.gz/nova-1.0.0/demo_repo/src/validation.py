"""Email validation module with a common regex bug."""
import re


def validate_email(email: str) -> bool:
    """
    Validate email address format.
    
    Note: This regex is too strict - it only allows 2-4 character TLDs,
    which will cause valid emails like 'user@mail.company.co.uk' to fail.
    """
    # Bug: Only allows TLDs of 2-4 characters, missing support for subdomains
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}$'
    
    if not email or not isinstance(email, str):
        return False
    
    return bool(re.match(email_pattern, email)) 