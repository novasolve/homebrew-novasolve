import pytest
from src.validation import validate_email


class TestEmailValidation:
    """Test email validation with various formats."""
    
    def test_basic_emails(self):
        """Test standard email formats."""
        assert validate_email("user@example.com") == True
        assert validate_email("test.user@company.org") == True
        assert validate_email("admin+tag@service.io") == True
    
    def test_complex_emails(self):
        """Test emails with subdomains and longer TLDs."""
        # This test will fail with the initial regex
        assert validate_email("user@mail.company.co.uk") == True
        assert validate_email("contact@blog.example.museum") == True
        assert validate_email("support@helpdesk.company.systems") == True
    
    def test_invalid_emails(self):
        """Test invalid email formats."""
        assert validate_email("notanemail") == False
        assert validate_email("@example.com") == False
        assert validate_email("user@") == False
        assert validate_email("user@@double.com") == False 