"""
Nova Demo: Authentication System Tests
======================================
These tests showcase common real-world bugs that Nova can intelligently fix.
Each test represents a different category of bug developers encounter daily.
"""

import hashlib
import time
import re
from datetime import datetime, timedelta
from typing import Dict, Optional, List


class AuthenticationSystem:
    """A realistic auth system with subtle bugs"""
    
    def __init__(self):
        self.users = {}
        self.sessions = {}
        self.rate_limits = {}
        self.password_reset_tokens = {}
        
    def register_user(self, email: str, password: str) -> Dict:
        """Register a new user with email validation"""
        # Email validation regex (has a bug!)
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$'
        
        if not re.match(email_pattern, email):
            return {"success": False, "error": "Invalid email format"}
            
        # Password hashing
        hashed = hashlib.sha256(password.encode()).hexdigest()
        self.users[email] = {
            "password_hash": hashed,
            "created_at": datetime.now(),
            "login_attempts": 0
        }
        
        return {"success": True, "user_id": len(self.users)}
    
    def login(self, email: str, password: str) -> Dict:
        """Authenticate user with rate limiting"""
        # Check rate limiting (bug: wrong time window!)
        if email in self.rate_limits:
            last_attempt = self.rate_limits[email]
            if time.time() - last_attempt < 60:  # Should be checking attempt count
                return {"success": False, "error": "Rate limited"}
        
        self.rate_limits[email] = time.time()
        
        if email not in self.users:
            return {"success": False, "error": "User not found"}
            
        user = self.users[email]
        hashed = hashlib.sha256(password.encode()).hexdigest()
        
        if user["password_hash"] == hashed:
            session_token = hashlib.sha256(f"{email}{time.time()}".encode()).hexdigest()
            self.sessions[session_token] = {
                "email": email,
                "created_at": datetime.now(),
                "expires_at": datetime.now() + timedelta(hours=24)
            }
            return {"success": True, "session_token": session_token}
        else:
            user["login_attempts"] += 1
            return {"success": False, "error": "Invalid password"}
    
    def verify_2fa(self, session_token: str, code: str) -> bool:
        """Verify 2FA code (bug: timing attack vulnerability)"""
        expected = self.generate_2fa_code(session_token)
        
        # Bug: Simple string comparison is vulnerable to timing attacks
        return expected == code
    
    def generate_2fa_code(self, session_token: str) -> str:
        """Generate a 6-digit 2FA code"""
        if session_token not in self.sessions:
            return "000000"
            
        # Generate based on session data
        seed = self.sessions[session_token]["email"]
        code = int(hashlib.sha256(seed.encode()).hexdigest(), 16) % 1000000
        return f"{code:06d}"
    
    def reset_password(self, email: str) -> Dict:
        """Initiate password reset"""
        if email not in self.users:
            # Bug: Leaks information about registered emails
            return {"success": False, "error": "Email not found"}
            
        reset_token = hashlib.sha256(f"{email}{time.time()}".encode()).hexdigest()[:16]
        self.password_reset_tokens[reset_token] = {
            "email": email,
            "created_at": datetime.now(),
            "expires_at": datetime.now() + timedelta(hours=1)
        }
        
        return {
            "success": True,
            "message": "Reset email sent",
            # Bug: Token exposed in response!
            "debug_token": reset_token
        }


# Test Suite with Intentional Failures
auth_system = AuthenticationSystem()


def test_email_validation_edge_cases():
    """Test 1: Email regex doesn't handle all valid formats"""
    # This should pass but fails due to regex not supporting '+' in domain
    result = auth_system.register_user("user@sub+domain.com", "SecurePass123!")
    assert result["success"] == True  # Fails: regex rejects valid email
    
    # This should also pass (numbers in domain)
    result2 = auth_system.register_user("admin@123startup.io", "SecurePass123!")
    assert result2["success"] == True  # Fails: regex too restrictive


def test_rate_limiting_logic():
    """Test 2: Rate limiting has wrong implementation"""
    email = "attacker@evil.com"
    
    # Register the attacker
    auth_system.register_user(email, "password")
    
    # Try 5 failed login attempts rapidly
    for i in range(5):
        auth_system.login(email, "wrongpassword")
    
    # The 6th attempt should be rate limited (but it's not!)
    result = auth_system.login(email, "wrongpassword")
    assert result["error"] == "Rate limited"  # Fails: rate limit not working correctly


def test_2fa_timing_attack_vulnerability():
    """Test 3: 2FA comparison vulnerable to timing attacks"""
    # Register and login
    auth_system.register_user("secure@user.com", "MyPassword123")
    login_result = auth_system.login("secure@user.com", "MyPassword123")
    session = login_result["session_token"]
    
    # Get the correct code
    correct_code = auth_system.generate_2fa_code(session)
    
    # Measure time for correct vs incorrect codes
    import timeit
    
    # This timing difference reveals information about the correct code
    correct_time = timeit.timeit(
        lambda: auth_system.verify_2fa(session, correct_code),
        number=1000
    )
    
    wrong_time = timeit.timeit(
        lambda: auth_system.verify_2fa(session, "000000"),
        number=1000
    )
    
    # Times should be constant to prevent timing attacks
    time_difference = abs(correct_time - wrong_time)
    assert time_difference < 0.001  # Fails: timing reveals information


def test_password_reset_information_leak():
    """Test 4: Password reset leaks user information"""
    # Try to reset password for non-existent user
    result1 = auth_system.reset_password("ghost@nowhere.com")
    
    # Try to reset for existing user
    auth_system.register_user("real@user.com", "RealPassword")
    result2 = auth_system.reset_password("real@user.com")
    
    # Both should return identical responses to prevent user enumeration
    assert result1.get("error") == result2.get("error")  # Fails: different responses
    
    # Also, the token should NEVER be in the response
    assert "debug_token" not in result2  # Fails: token exposed in response!


def test_session_expiry_validation():
    """Test 5: Session expiry not properly validated"""
    # Register and login
    auth_system.register_user("timetest@user.com", "TimePass123")
    login_result = auth_system.login("timetest@user.com", "TimePass123")
    session = login_result["session_token"]
    
    # Manually expire the session
    auth_system.sessions[session]["expires_at"] = datetime.now() - timedelta(hours=1)
    
    # Try to use expired session for 2FA
    code = auth_system.generate_2fa_code(session)
    assert code == "000000"  # Fails: expired sessions still generate valid codes


def test_concurrent_session_handling():
    """Test 6: Multiple sessions not handled correctly"""
    # Fresh auth system to avoid conflicts
    fresh_auth = AuthenticationSystem()
    email = "multi@user.com"
    fresh_auth.register_user(email, "MultiPass123")
    
    # Create 3 sessions
    sessions = []
    for i in range(3):
        result = fresh_auth.login(email, "MultiPass123")
        if "session_token" in result:
            sessions.append(result["session_token"])
        time.sleep(0.1)  # Small delay
    
    # Should have 3 sessions
    assert len(sessions) == 3, f"Only got {len(sessions)} sessions"
    
    # All sessions should be valid
    codes = [fresh_auth.generate_2fa_code(s) for s in sessions]
    
    # Each session should have a unique code (but they don't!)
    assert len(set(codes)) == 3  # Fails: all sessions generate same code


def test_password_complexity_validation():
    """Test 7: Weak password complexity checking"""
    # These weak passwords should be rejected but aren't
    weak_passwords = [
        "password123",  # Too common
        "12345678",     # Sequential numbers
        "aaaaaaaa",     # Repeated character
        "qwertyui",     # Keyboard pattern
    ]
    
    results = []
    for i, pwd in enumerate(weak_passwords):
        result = auth_system.register_user(f"weak{i}@test.com", pwd)
        results.append(result["success"])
    
    # All weak passwords should be rejected
    assert all(not success for success in results)  # Fails: no password validation


# Execution guard
if __name__ == "__main__":
    print("Running Nova demo tests...")
    print("These tests are intentionally failing to showcase Nova's capabilities.")
    print("Run with pytest to see the failures!") 