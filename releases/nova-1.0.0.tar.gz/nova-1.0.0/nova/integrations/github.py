"""
GitHub Integration for Nova 1.0
Real OAuth flow with browser authentication and Upstash Redis storage
"""

import os
import sys
import json
import time
import secrets
import webbrowser
import asyncio
import threading
from pathlib import Path
from typing import Optional, Dict, Any
from urllib.parse import urlencode, parse_qs, urlparse
from http.server import HTTPServer, BaseHTTPRequestHandler
import subprocess

# Try to import redis
try:
    import redis
    HAS_REDIS = True
except ImportError:
    HAS_REDIS = False
    print("Warning: redis package not installed. Install with: pip install redis")


class GitHubOAuthHandler(BaseHTTPRequestHandler):
    """Handle OAuth callback from GitHub"""
    
    def do_GET(self):
        """Handle GET request from GitHub OAuth callback"""
        parsed_url = urlparse(self.path)
        
        if parsed_url.path == "/callback":
            query_params = parse_qs(parsed_url.query)
            
            # Extract auth code
            if 'code' in query_params:
                self.server.auth_code = query_params['code'][0]
                self.server.state = query_params.get('state', [''])[0]
                
                # Send success response
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                
                success_html = """
                <html>
                <head>
                    <title>Nova - GitHub Connected</title>
                    <style>
                        body { 
                            font-family: -apple-system, sans-serif; 
                            text-align: center; 
                            padding: 50px;
                            background: #0d1117;
                            color: #c9d1d9;
                        }
                        .success { 
                            color: #3fb950; 
                            font-size: 48px; 
                            margin-bottom: 20px; 
                        }
                        .message {
                            font-size: 20px;
                            margin-bottom: 30px;
                        }
                    </style>
                </head>
                <body>
                    <div class="success">✅</div>
                    <div class="message">GitHub authorization successful!</div>
                    <p>You can close this window and return to Nova.</p>
                    <script>window.setTimeout(() => window.close(), 3000);</script>
                </body>
                </html>
                """
                self.wfile.write(success_html.encode())
            else:
                # Error response
                self.send_response(400)
                self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress HTTP server logs"""
        pass


class GitHubIntegration:
    """GitHub OAuth integration with Upstash Redis storage"""
    
    def __init__(self):
        self.github_app_id = os.getenv("GITHUB_APP_ID", "1434475")
        self.github_client_id = os.getenv("GITHUB_CLIENT_ID", "Iv23liiZaWy61CvjQQdz")
        self.github_client_secret = os.getenv("GITHUB_CLIENT_SECRET", "f3c8e3b4e50877c9a4b8b0c9aee3a8a31e7c8a3f")
        self.github_private_key = os.getenv("GITHUB_PRIVATE_KEY", "")
        
        # Upstash Redis configuration
        self.redis_url = os.getenv("UPSTASH_REDIS_URL", os.getenv("REDIS_URL", ""))
        self.redis_client = None
        
        # OAuth settings
        self.callback_port = 9876
        self.callback_url = f"http://localhost:{self.callback_port}/callback"
        self.state = None
        self.server = None
        
        # Local storage fallback
        self.config_dir = Path.home() / ".nova"
        self.config_dir.mkdir(exist_ok=True)
        self.token_file = self.config_dir / "github_token.json"
        
        # Initialize Redis if available
        self._init_redis()
        
    def _init_redis(self):
        """Initialize Upstash Redis client"""
        if HAS_REDIS and self.redis_url:
            try:
                self.redis_client = redis.from_url(
                    self.redis_url,
                    decode_responses=True,
                    socket_connect_timeout=5,
                    socket_timeout=5
                )
                # Test connection
                self.redis_client.ping()
                print("✅ Connected to Upstash Redis")
            except Exception as e:
                print(f"⚠️  Redis connection failed: {e}")
                print("   Falling back to local storage")
                self.redis_client = None
        else:
            if not HAS_REDIS:
                print("⚠️  Redis package not installed")
            if not self.redis_url:
                print("⚠️  UPSTASH_REDIS_URL not set")
            print("   Using local storage for GitHub data")
    
    def get_stored_installation(self) -> Optional[Dict[str, Any]]:
        """Get stored GitHub installation data"""
        # Try Redis first
        if self.redis_client:
            try:
                data = self.redis_client.hgetall("nova:github:installation")
                if data:
                    return data
            except Exception as e:
                print(f"Redis read error: {e}")
        
        # Fallback to local file
        if self.token_file.exists():
            try:
                return json.loads(self.token_file.read_text())
            except:
                pass
        
        return None
    
    def store_installation(self, data: Dict[str, Any]):
        """Store GitHub installation data"""
        # Store in Redis if available
        if self.redis_client:
            try:
                self.redis_client.hset("nova:github:installation", mapping=data)
                # Also set an expiry (30 days)
                self.redis_client.expire("nova:github:installation", 30 * 24 * 60 * 60)
                print("✅ Stored installation data in Upstash Redis")
            except Exception as e:
                print(f"Redis write error: {e}")
        
        # Always store locally as backup
        self.token_file.write_text(json.dumps(data, indent=2))
    
    def is_authenticated(self) -> bool:
        """Check if we have valid GitHub authentication"""
        installation = self.get_stored_installation()
        return bool(installation and installation.get('access_token'))
    
    def get_username(self) -> Optional[str]:
        """Get authenticated GitHub username"""
        installation = self.get_stored_installation()
        if installation:
            return installation.get('username')
        
        # Try git config as fallback
        try:
            result = subprocess.run(
                ["git", "config", "user.name"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        
        return None
    
    async def authenticate(self) -> bool:
        """Run the full OAuth authentication flow"""
        print("\n🔐 Starting GitHub authentication...")
        
        # Check environment
        if not self.github_client_secret:
            print("❌ GITHUB_CLIENT_SECRET not set!")
            print("   Please set it in your environment or .env file")
            return False
        
        # Generate state for CSRF protection
        self.state = secrets.token_urlsafe(32)
        
        # Start callback server
        if not await self._start_callback_server():
            return False
        
        # Generate OAuth URL
        oauth_params = {
            "client_id": self.github_client_id,
            "redirect_uri": self.callback_url,
            "scope": "repo write:org read:user",
            "state": self.state
        }
        oauth_url = f"https://github.com/login/oauth/authorize?{urlencode(oauth_params)}"
        
        print(f"📱 Opening browser for GitHub authorization...")
        print(f"   If browser doesn't open, visit: {oauth_url}")
        
        # Open browser
        webbrowser.open(oauth_url)
        
        # Wait for callback
        print("⏳ Waiting for authorization...")
        auth_code = await self._wait_for_callback()
        
        if not auth_code:
            print("❌ Authorization timeout or cancelled")
            self._stop_callback_server()
            return False
        
        # Exchange code for token
        print("🔄 Exchanging authorization code for access token...")
        token_data = await self._exchange_code_for_token(auth_code)
        
        if not token_data:
            return False
        
        # Get user info
        user_info = await self._get_user_info(token_data['access_token'])
        
        if user_info:
            # Store everything
            installation_data = {
                'access_token': token_data['access_token'],
                'token_type': token_data.get('token_type', 'bearer'),
                'scope': token_data.get('scope', ''),
                'username': user_info['login'],
                'user_id': str(user_info['id']),
                'name': user_info.get('name', ''),
                'email': user_info.get('email', ''),
                'installation_id': '',  # Will be filled when installing the GitHub App
                'authenticated_at': time.time()
            }
            
            self.store_installation(installation_data)
            
            print(f"✅ Authenticated as @{user_info['login']}")
            return True
        
        return False
    
    async def _start_callback_server(self) -> bool:
        """Start local HTTP server for OAuth callback"""
        try:
            self.server = HTTPServer(('localhost', self.callback_port), GitHubOAuthHandler)
            self.server.auth_code = None
            self.server.state = None
            
            # Run server in background thread
            server_thread = threading.Thread(target=self.server.serve_forever)
            server_thread.daemon = True
            server_thread.start()
            
            return True
        except Exception as e:
            print(f"❌ Failed to start callback server: {e}")
            return False
    
    def _stop_callback_server(self):
        """Stop the callback server"""
        if self.server:
            self.server.shutdown()
            self.server = None
    
    async def _wait_for_callback(self, timeout: int = 120) -> Optional[str]:
        """Wait for OAuth callback with timeout"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            if self.server and self.server.auth_code:
                # Verify state matches
                if self.server.state == self.state:
                    auth_code = self.server.auth_code
                    self._stop_callback_server()
                    return auth_code
                else:
                    print("❌ State mismatch - possible CSRF attack")
                    self._stop_callback_server()
                    return None
            
            await asyncio.sleep(0.5)
        
        self._stop_callback_server()
        return None
    
    async def _exchange_code_for_token(self, code: str) -> Optional[Dict[str, Any]]:
        """Exchange OAuth code for access token"""
        try:
            # Use httpx if available, otherwise urllib
            try:
                import httpx
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        "https://github.com/login/oauth/access_token",
                        headers={"Accept": "application/json"},
                        data={
                            "client_id": self.github_client_id,
                            "client_secret": self.github_client_secret,
                            "code": code
                        }
                    )
                    return response.json()
            except ImportError:
                # Fallback to urllib
                import urllib.request
                import urllib.parse
                
                data = urllib.parse.urlencode({
                    "client_id": self.github_client_id,
                    "client_secret": self.github_client_secret,
                    "code": code
                }).encode()
                
                req = urllib.request.Request(
                    "https://github.com/login/oauth/access_token",
                    data=data,
                    headers={"Accept": "application/json"}
                )
                
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
                    
        except Exception as e:
            print(f"❌ Token exchange failed: {e}")
            return None
    
    async def _get_user_info(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get GitHub user information"""
        try:
            # Use httpx if available, otherwise urllib
            try:
                import httpx
                async with httpx.AsyncClient() as client:
                    response = await client.get(
                        "https://api.github.com/user",
                        headers={"Authorization": f"token {access_token}"}
                    )
                    return response.json()
            except ImportError:
                # Fallback to urllib
                import urllib.request
                
                req = urllib.request.Request(
                    "https://api.github.com/user",
                    headers={"Authorization": f"token {access_token}"}
                )
                
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
                    
        except Exception as e:
            print(f"❌ Failed to get user info: {e}")
            return None
    
    def get_installation_id(self) -> Optional[str]:
        """Get stored GitHub App installation ID"""
        installation = self.get_stored_installation()
        if installation:
            return installation.get('installation_id')
        return None
    
    def set_installation_id(self, installation_id: str):
        """Store GitHub App installation ID"""
        installation = self.get_stored_installation() or {}
        installation['installation_id'] = installation_id
        self.store_installation(installation) 