"""
Backend module for Nova
""" 