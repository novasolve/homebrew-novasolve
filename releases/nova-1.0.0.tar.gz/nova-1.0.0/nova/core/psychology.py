"""
Psychology stack for Nova 1.0
Implements the five ROI-positive triggers.
"""

import random
import time
from datetime import datetime, timedelta
from typing import Optional

from nova.utils.colors import Colors
from nova.core.config import Config


class PsychologyEngine:
    """
    Handles the five psychology triggers:
    1. Reciprocity - 100 credits gift
    2. Social Proof - Footer ticker
    3. Scarcity - Expiration notice
    4. Variable Reward - Rare ASCII constellation
    5. Unity - Founding member number
    """
    
    def __init__(self, config: Config):
        self.config = config
        self.colors = Colors()
        
    def show_reciprocity_gift(self):
        """Show the 100 credits gift (already shown in onboarding)"""
        # This is handled in the onboarding flow
        pass
        
    def get_social_proof_ticker(self) -> Optional[str]:
        """
        Generate social proof ticker message.
        Shows recent activity from other users.
        """
        # Sample companies for demo (in production, would be real data)
        companies = ['ACME', 'TechCorp', 'StartupXYZ', 'DevTools Inc', 'CloudBase']
        actions = ['merged green PR', 'fixed 12 tests', 'saved 2 hours', 'shipped feature']
        times = ['2m ago', '5m ago', '11m ago', '18m ago', '1h ago']
        
        company = random.choice(companies)
        action = random.choice(actions)
        time_ago = random.choice(times)
        
        return f"💼 {company} {action} {time_ago}"
    
    def show_scarcity_notice(self):
        """Show credit expiration notice if applicable"""
        credits = self.config.get_credits()
        if credits > 0 and credits == 100:  # Still on initial gift
            # Calculate 30 days from first run
            first_run = self.config._config.get('first_run_timestamp')
            if first_run:
                expiry = datetime.fromtimestamp(first_run) + timedelta(days=30)
                days_left = (expiry - datetime.now()).days
                if days_left > 0 and days_left <= 30:
                    # Small grey text as specified
                    print(f"\033[90mcredits expire in {days_left} days\033[0m")
    
    def check_variable_reward(self) -> bool:
        """
        1% chance to show rare ASCII constellation.
        Returns True if constellation should be shown.
        """
        return random.random() < 0.01
    
    def show_constellation(self):
        """Display the rare ASCII constellation"""
        constellation = """
        ☄︎ You discovered Nova's comet!
        
             .  *  .   ☄︎
          .  ·  ✦  ·  .
        ·   ⊹   ✧   ⊹   ·
          ˚  ·  ✦  ·  ˚
             ·  *  ·
        """
        print(f"\n{self.colors.CYAN}{constellation}{self.colors.RESET}\n")
    
    def assign_founding_number(self) -> Optional[int]:
        """
        Assign founding member number after first paid PR.
        In production, this would be a real sequential number.
        """
        if not self.config._config.get('founding_number'):
            # For demo, generate a low number to feel exclusive
            number = random.randint(10, 200)
            self.config.set_founding_number(number)
            return number
        return None
    
    def show_unity_message(self, number: int):
        """Show the founding member message"""
        print(f"\n{self.colors.SUCCESS}You're Founding #{number}{self.colors.RESET}\n") 