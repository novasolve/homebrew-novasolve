"""
Micro-copy library for Nova 1.0
Only 10 lines allowed. If a new line is proposed, another must be deleted.
Following Collison's "string budget" rule.
"""


class MicroCopy:
    """
    The complete set of micro-copy for Nova 1.0.
    Exactly 10 lines, no more, no less.
    """
    
    # The 10 allowed lines (production copy)
    DEMO_START = "Breathing life into a failing test..."
    DEMO_PASS = "diff saved to /tmp/nova_demo.patch"
    AUTH_SUCCESS = "✓ Linked to @username"
    FIX_START = "Synthesizing remedy #1..."
    FIX_PASS = "✅ test_auth.py::test_login fixed in 1.1s"
    ALL_GREEN = "All tests passing."
    CREDIT_SPEND = "-$5 • 92 credits"
    CREDIT_LOW = "10 credits remaining"
    EASTER_EGG = "☄︎ You discovered Nova's comet!"
    ERROR_FALLBACK = "Retrying..."
    
    @classmethod
    def format_fix_pass(cls, test_name: str, duration: float) -> str:
        """Format the fix pass message with actual test name and duration"""
        return f"✅ {test_name} fixed in {duration:.1f}s"
    
    @classmethod
    def format_credit_spend(cls, amount: int, remaining: int) -> str:
        """Format the credit spend message with actual amounts"""
        return f"-${amount} • {remaining} credits"
    
    @classmethod
    def format_credit_low(cls, remaining: int) -> str:
        """Format the low credit warning with actual amount"""
        return f"{remaining} credits remaining" 