"""
Test fixer for Nova 1.0
Generates and applies fixes for failing tests
"""

import asyncio
from pathlib import Path
from typing import List, Dict, Any
import difflib

from nova.backend.gateway import NovaGateway
from nova.utils.colors import Colors


class TestFixer:
    """Fix failing tests using AI"""
    
    def __init__(self):
        self.gateway = NovaGateway()
        self.colors = Colors()
    
    async def fix_all(self, failing_tests: List[Dict[str, Any]]):
        """Fix all failing tests"""
        total = len(failing_tests)
        
        for i, test in enumerate(failing_tests, 1):
            print(f"\n{self.colors.CYAN}Synthesizing remedy #{i}...{self.colors.RESET}")
            
            # Generate fix using the backend gateway
            fix_result = await self.fix_single_test(test)
            
            if fix_result['success']:
                # Apply the fix
                if await self.apply_fix(fix_result):
                    print(f"{self.colors.GREEN}✓ Fixed {test['name']}{self.colors.RESET}")
                else:
                    print(f"{self.colors.RED}✗ Could not apply fix for {test['name']}{self.colors.RESET}")
            else:
                print(f"{self.colors.RED}✗ Could not generate fix for {test['name']}{self.colors.RESET}")
        
        print(f"\n{self.colors.GREEN}All tests processed!{self.colors.RESET}")
    
    async def fix_single_test(self, test_info: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a fix for a single test using AI"""
        test_file = test_info['file']
        test_name = test_info['name']
        
        # Use the gateway to generate AI-powered fix
        # The gateway will use nova-source's actual AI implementation
        fix_result = await self.gateway.fix_test(test_file, test_name)
        
        # Add original test info to result
        fix_result['test_info'] = test_info
        
        return fix_result
    
    async def apply_fix(self, fix_result: Dict[str, Any]) -> bool:
        """Apply a fix to the file"""
        if not fix_result.get('success'):
            return False
            
        if 'patch' in fix_result and fix_result['patch']:
            # Apply the patch using git apply
            import subprocess
            import tempfile
            
            test_file = fix_result.get('test_file', fix_result['test_info']['file'])
            patch_content = fix_result['patch']
            
            # Save patch to temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.patch', delete=False) as f:
                f.write(patch_content)
                patch_file = f.name
            
            try:
                # Apply the patch
                result = subprocess.run(
                    ['git', 'apply', '--whitespace=fix', patch_file],
                    cwd=Path.cwd(),
                    capture_output=True,
                    text=True
                )
                
                if result.returncode == 0:
                    print(f"  Applied patch to {test_file}")
                    return True
                else:
                    print(f"  Failed to apply patch: {result.stderr}")
                    return False
                    
            finally:
                # Clean up patch file
                Path(patch_file).unlink(missing_ok=True)
        
        return False
    
    def generate_diff(self, original: str, fixed: str, filename: str) -> str:
        """Generate a unified diff"""
        original_lines = original.splitlines(keepends=True)
        fixed_lines = fixed.splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            original_lines,
            fixed_lines,
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
            lineterm=''
        )
        
        return ''.join(diff) 