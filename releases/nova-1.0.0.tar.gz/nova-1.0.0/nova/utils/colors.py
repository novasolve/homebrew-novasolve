"""
Colors for Nova 1.0
Only four ANSI colors: neutral text, accent-cyan, success-green, error-red.
"""

import os


class Colors:
    """Minimal color palette for Nova 1.0"""
    
    # Check if colors should be disabled
    NO_COLOR = os.environ.get('NO_COLOR') or os.environ.get('NOVA_MINIMAL')
    
    # The only four colors allowed
    RESET = '\033[0m' if not NO_COLOR else ''
    CYAN = '\033[36m' if not NO_COLOR else ''    # Accent cyan
    GREEN = '\033[32m' if not NO_COLOR else ''   # Success green  
    RED = '\033[31m' if not NO_COLOR else ''     # Error red
    BOLD = '\033[1m' if not NO_COLOR else ''     # Bold text
    
    # Semantic aliases
    ACCENT = CYAN
    SUCCESS = GREEN
    ERROR = RED
    
    @classmethod
    def strip_colors(cls, text: str) -> str:
        """Remove all ANSI color codes from text"""
        import re
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text) 