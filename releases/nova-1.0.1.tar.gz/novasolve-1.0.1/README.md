# Nova - AI Teammate That Fixes Failing Tests Fast

## ⚠️ PRIVATE CODE - DO NOT DISTRIBUTE

**This is proprietary code. NEVER use MIT license. This code is private and confidential.**

**The execution layer for imagination.**  
*It fixes your failing Python tests by opening clean PRs.*

```bash
$ nova
```

That's it. Nova fixes your failing tests using AI, so you can focus on building.

## Installation

Install via Homebrew:

```bash
brew tap novasolve/novasolve
brew install novasolve
```

## Configuration

Set your environment variables:

```bash
export GITHUB_CLIENT_ID="Iv23liiZaWy61CvjQQdz"
export GITHUB_CLIENT_SECRET="your_secret"
export UPSTASH_REDIS_URL="rediss://your_redis_url"
```

## Usage

```bash
nova
```

This will start the onboarding experience with:
- GitHub OAuth authentication
- Email validation regex demo
- Connection to your repositories

## About

Nova is developed by [JoinNova.com](https://joinnova.com).

© 2024 JoinNova.com - All Rights Reserved. Proprietary and Confidential.

## First Run

Nova includes 100 PR credits as a gift. Your first run takes about 60 seconds.

```
Nova 1.0 — The execution layer for imagination.
100 PR credits loaded • ≈60 s first run

Sandbox test: fixing a failure in real time...
▁▂▃▄▅▆▇█ 100 % • green ✅

Press Enter to link GitHub (@yourname)
```

## Usage

When tests fail, Nova offers three choices:

```
Found 7 failing tests in feature/login-2fa
Cost: 7 × $5  ➜  $35  (credits 93/100)
[Y] Fix all   [D] Diff first   [Q] Quit
```

Press Y. Nova handles the rest.

## Pricing

- $5 per test fixed
- Buy credits at [novasolve.ai](https://novasolve.ai)
- Monthly subscriptions available

## Requirements

- Python 3.8+
- Git repository with tests
- GitHub account (for PR creation)

---

## Copy & Design Guidelines

### Staying Beautiful (Without the Cosmic Mumbo-Jumbo)

To keep Nova in the "beautiful-product" region:

#### 1. **Tight Constraints**
- **Scope**: CLI onboarding flow only; 120s max; no metaphors beyond *imagination*
- **Voice**: Apple-grade minimalism, Stripe-grade clarity
- **Forbidden**: orbit, cosmic, universe, pulse, cycle, celestial, journey, etc.

#### 2. **Layered Approach**
- **Layer 1**: Structure & timing (beats, durations, CTAs)
- **Layer 2**: Placeholders ("TAGLINE", "PRICE_LINE")
- **Layer 3**: Fill placeholders one at a time

#### 3. **String Budget**
- Maximum 10 visible lines
- Any new sentence must replace an old one
- Forces concision and quality

#### 4. **Concrete Anchors**
Every line must map to:
- Speed (how fast)
- Trust (social proof)
- Price (transparency)
- Action (what to do)

#### 5. **Fixed Vocabulary**
- **Allowed**: imagination, fix, PR, Python, seconds, $5, test, credits
- **Colors**: neutral, cyan, green, red only
- **Reject** anything outside this palette

#### 6. **Review Cadence**
1. Wireframe only (no prose)
2. One-word placeholders
3. Short phrases (≤6 words)
4. Full lines
5. Stop when it feels right

### The Tagline

"The execution layer for imagination" works because:
- It evokes ambition
- It differentiates immediately
- It's immediately grounded by "It fixes your failing Python tests"

This two-step (vision → function) keeps both awe and clarity.

---

*Built with craftsmanship by [NovaSolve](https://novasolve.ai)* 