from importlib import import_module as _im
globals().update(_im("novasolve").__dict__)
