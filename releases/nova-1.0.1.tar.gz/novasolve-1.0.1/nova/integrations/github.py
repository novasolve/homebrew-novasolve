"""
GitHub Integration for Nova 1.0
Real OAuth flow with browser authentication using Nova backend API
"""

import os
import sys
import json
import time
import secrets
import webbrowser
import asyncio
import threading
from pathlib import Path
from typing import Optional, Dict, Any, cast
from urllib.parse import urlencode, parse_qs, urlparse
from http.server import HTTPServer, BaseHTTPRequestHandler
import subprocess

# Import httpx for API calls (with fallback to urllib)
try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False
    import urllib.request
    import urllib.parse


# Shared data for OAuth callback
oauth_callback_data: Dict[str, Optional[str]] = {
    'auth_code': None,
    'state': None
}


class GitHubOAuthHandler(BaseHTTPRequestHandler):
    """Handle OAuth callback from GitHub"""
    
    def do_GET(self):
        """Handle GET request from GitHub OAuth callback"""
        parsed_url = urlparse(self.path)
        
        if parsed_url.path == "/callback":
            query_params = parse_qs(parsed_url.query)
            
            # Extract auth code
            if 'code' in query_params:
                # Store in global shared data
                oauth_callback_data['auth_code'] = query_params['code'][0]
                oauth_callback_data['state'] = query_params.get('state', [''])[0]
                
                # Send success response
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                
                success_html = """
                <html>
                <head>
                    <title>Nova - GitHub Connected</title>
                    <style>
                        body { 
                            font-family: -apple-system, sans-serif; 
                            text-align: center; 
                            padding: 50px;
                            background: #0d1117;
                            color: #c9d1d9;
                        }
                        .success { 
                            color: #3fb950; 
                            font-size: 48px; 
                            margin-bottom: 20px; 
                        }
                        .message {
                            font-size: 20px;
                            margin-bottom: 30px;
                        }
                    </style>
                </head>
                <body>
                    <div class="success">✅</div>
                    <div class="message">GitHub authorization successful!</div>
                    <p>You can close this window and return to Nova.</p>
                    <script>window.setTimeout(() => window.close(), 3000);</script>
                </body>
                </html>
                """
                self.wfile.write(success_html.encode())
            else:
                # Error response
                self.send_response(400)
                self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress HTTP server logs"""
        pass


class GitHubIntegration:
    """GitHub OAuth integration using Nova backend API"""
    
    def __init__(self):
        # Get backend URL from environment or use default
        self.backend_url = os.getenv("NOVA_BACKEND_URL", "https://nova-worker-production.up.railway.app")
        self.api_base = f"{self.backend_url}/api/cli"
        
        # OAuth settings
        self.callback_port = 9876
        self.callback_url = f"http://localhost:{self.callback_port}/callback"
        self.state = None
        self.server = None
        self.auth_token = None
        
        # Local storage fallback
        self.config_dir = Path.home() / ".nova"
        self.config_dir.mkdir(exist_ok=True)
        self.token_file = self.config_dir / "github_token.json"
        
        # Check backend connectivity
        self._check_backend_connectivity()
    
    def _check_backend_connectivity(self):
        """Check if we can connect to the Nova backend"""
        try:
            response = self._api_request("GET", "/health")
            if response and response.get("status") == "ok":
                print("✅ Connected to Nova backend")
            else:
                print("⚠️  Nova backend returned unexpected response")
        except Exception as e:
            print(f"⚠️  Cannot connect to Nova backend: {e}")
            print("   Some features may be limited")
    
    def _api_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Optional[Dict]:
        """Make API request to Nova backend"""
        url = f"{self.api_base}{endpoint}"
        
        if HAS_HTTPX:
            # Use httpx (synchronous for simplicity)
            try:
                with httpx.Client(timeout=30.0) as client:
                    if method == "GET":
                        response = client.get(url)
                    elif method == "POST":
                        response = client.post(url, json=data)
                    else:
                        raise ValueError(f"Unsupported method: {method}")
                    
                    response.raise_for_status()
                    return response.json()
            except Exception as e:
                print(f"API request failed: {e}")
                return None
        else:
            # Fallback to urllib
            try:
                if method == "GET":
                    req = urllib.request.Request(url)
                elif method == "POST":
                    data_bytes = json.dumps(data).encode() if data else b"{}"
                    req = urllib.request.Request(
                        url,
                        data=data_bytes,
                        headers={"Content-Type": "application/json"}
                    )
                else:
                    raise ValueError(f"Unsupported method: {method}")
                
                with urllib.request.urlopen(req) as response:
                    return json.loads(response.read().decode())
            except Exception as e:
                print(f"API request failed: {e}")
                return None
    
    async def _api_request_async(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Optional[Dict]:
        """Async version of API request"""
        url = f"{self.api_base}{endpoint}"
        
        if HAS_HTTPX:
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    if method == "GET":
                        response = await client.get(url)
                    elif method == "POST":
                        response = await client.post(url, json=data)
                    else:
                        raise ValueError(f"Unsupported method: {method}")
                    
                    response.raise_for_status()
                    return response.json()
            except Exception as e:
                print(f"API request failed: {e}")
                return None
        else:
            # For urllib, we'll use run_in_executor to make it async
            import concurrent.futures
            loop = asyncio.get_event_loop()
            
            def sync_request():
                return self._api_request(method, endpoint, data)
            
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return await loop.run_in_executor(pool, sync_request)
    
    def get_stored_installation(self) -> Optional[Dict[str, Any]]:
        """Get stored GitHub installation data"""
        # Try backend API first
        try:
            response = self._api_request("GET", "/github/installation")
            if response:
                return response
        except Exception as e:
            print(f"Failed to get installation from backend: {e}")
        
        # Fallback to local file
        if self.token_file.exists():
            try:
                return json.loads(self.token_file.read_text())
            except:
                pass
        
        return None
    
    def store_installation(self, data: Dict[str, Any]):
        """Store GitHub installation data"""
        # Store via backend API
        try:
            response = self._api_request("POST", "/github/installation", data)
            if response and response.get("success"):
                print("✅ Stored installation data via Nova backend")
        except Exception as e:
            print(f"Failed to store via backend: {e}")
        
        # Always store locally as backup
        self.token_file.write_text(json.dumps(data, indent=2))
    
    def is_authenticated(self) -> bool:
        """Check if we have valid GitHub authentication"""
        installation = self.get_stored_installation()
        return bool(installation and installation.get('access_token'))
    
    def get_username(self) -> Optional[str]:
        """Get authenticated GitHub username"""
        installation = self.get_stored_installation()
        if installation:
            return installation.get('username')
        
        # Try git config as fallback
        try:
            result = subprocess.run(
                ["git", "config", "user.name"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        
        return None
    
    async def authenticate(self) -> bool:
        """Run the full OAuth authentication flow"""
        print("\n🔐 Starting GitHub authentication...")
        
        # Initialize auth session with backend
        init_response = await self._api_request_async(
            "POST", 
            "/github/auth/init",
            {
                "callback_url": self.callback_url
            }
        )
        
        if not init_response:
            print("❌ Failed to initialize authentication with Nova backend")
            return False
        
        self.auth_token = init_response.get("auth_token")
        oauth_url = init_response.get("oauth_url")
        
        # Extract state from oauth_url safely
        if oauth_url and "state=" in oauth_url:
            self.state = oauth_url.split("state=")[-1].split("&")[0]
        else:
            self.state = None
        
        # Start callback server
        if not await self._start_callback_server():
            return False
        
        print(f"📱 Opening browser for GitHub authorization...")
        print(f"   If browser doesn't open, visit: {oauth_url}")
        
        # Open browser
        if oauth_url:
            webbrowser.open(oauth_url)
        
        # Wait for callback
        print("⏳ Waiting for authorization...")
        auth_code = await self._wait_for_callback()
        
        if not auth_code:
            print("❌ Authorization timeout or cancelled")
            self._stop_callback_server()
            return False
        
        # Complete auth with backend
        print("🔄 Completing authentication...")
        complete_response = await self._api_request_async(
            "POST",
            "/github/auth/complete",
            {
                "auth_token": self.auth_token,
                "code": auth_code,
                "state": self.state
            }
        )
        
        if not complete_response or not complete_response.get("success"):
            print("❌ Failed to complete authentication")
            return False
        
        username = complete_response.get("username")
        user_id = complete_response.get("user_id")
        
        print(f"✅ Authenticated as @{username}")
        
        # Store locally as well for offline access
        installation_data = {
            'username': username,
            'user_id': user_id,
            'authenticated_at': time.time()
        }
        self.token_file.write_text(json.dumps(installation_data, indent=2))
        
        return True
    
    async def _start_callback_server(self) -> bool:
        """Start local HTTP server for OAuth callback"""
        try:
            # Reset shared data
            oauth_callback_data['auth_code'] = None
            oauth_callback_data['state'] = None
            
            self.server = HTTPServer(('localhost', self.callback_port), GitHubOAuthHandler)
            
            # Run server in background thread
            server_thread = threading.Thread(target=self.server.serve_forever)
            server_thread.daemon = True
            server_thread.start()
            
            return True
        except Exception as e:
            print(f"❌ Failed to start callback server: {e}")
            return False
    
    def _stop_callback_server(self):
        """Stop the callback server"""
        if self.server:
            self.server.shutdown()
            self.server = None
    
    async def _wait_for_callback(self, timeout: int = 120) -> Optional[str]:
        """Wait for OAuth callback with timeout"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            if oauth_callback_data['auth_code']:
                # Verify state matches
                if oauth_callback_data['state'] == self.state:
                    auth_code = oauth_callback_data['auth_code']
                    self._stop_callback_server()
                    return auth_code
                else:
                    print("❌ State mismatch - possible CSRF attack")
                    self._stop_callback_server()
                    return None
            
            # Also poll backend for status
            if self.auth_token:
                status_response = await self._api_request_async(
                    "GET",
                    f"/github/auth/status?auth_token={self.auth_token}"
                )
                
                if status_response and status_response.get("status") == "completed":
                    self._stop_callback_server()
                    return "backend_completed"  # Special marker
            
            await asyncio.sleep(0.5)
        
        self._stop_callback_server()
        return None
    
    def get_installation_id(self) -> Optional[str]:
        """Get stored GitHub App installation ID"""
        installation = self.get_stored_installation()
        if installation:
            return installation.get('installation_id')
        return None
    
    def set_installation_id(self, installation_id: str):
        """Store GitHub App installation ID"""
        installation = self.get_stored_installation() or {}
        installation['installation_id'] = installation_id
        self.store_installation(installation) 