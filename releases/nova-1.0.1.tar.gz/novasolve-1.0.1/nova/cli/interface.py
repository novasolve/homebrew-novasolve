"""
Main interface for Nova 1.0
Shows the first real action with exact copy from specification.
"""

import sys
from typing import List, Optional
from pathlib import Path

from nova.utils.colors import Colors
from nova.core.test_finder import TestFinder
from nova.core.pricing import PricingEngine
from nova.core.config import Config
from nova.core.psychology import PsychologyEngine


class NovaInterface:
    """Main user interface after onboarding"""
    
    def __init__(self):
        self.colors = Colors()
        self.config = Config()
        self.test_finder = TestFinder()
        self.pricing = PricingEngine()
        self.psychology = PsychologyEngine(self.config)
        
    async def show_main_prompt(self):
        """
        Show the first real action prompt.
        Exact format from specification:
        
        Found 7 failing tests in feature/login-2fa
        Cost: 7 × $5  ➜  $35  (credits 93/100)
        [Y] Fix all   [D] Diff first   [Q] Quit
        """
        # Find failing tests
        failing_tests = await self.test_finder.find_failing_tests()
        
        if not failing_tests:
            print("\nAll tests passing.")
            return
            
        # Get branch/location info
        location = self.test_finder.get_test_location(failing_tests)
        test_count = len(failing_tests)
        
        # Calculate credits needed
        credits_needed = test_count  # 1 credit per test
        current_credits = self.config.get_credits()
        remaining_credits = current_credits - credits_needed
        
        # Display the prompt with production formatting
        print()
        print(f"Found {test_count} failing tests in {location}")
        print()
        print(f"Credits: {credits_needed} needed  ({remaining_credits} will remain)")
        print()
        print("[Y] Fix all   [D] Diff first   [Q] Quit")
        
        # Show social proof ticker in background
        from nova.core.social_proof import SocialProofTicker
        ticker = SocialProofTicker()
        
        # Get single-key input
        choice = await self._get_single_key_input()
        
        await self._handle_choice(choice, failing_tests, credits_needed)
        
        # Show expiration notice if applicable
        self.psychology.show_scarcity_notice()
    
    async def _get_single_key_input(self) -> str:
        """Get a single keypress from the user"""
        import termios
        import tty
        
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        
        try:
            tty.setraw(sys.stdin.fileno())
            choice = sys.stdin.read(1).lower()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            
        return choice
    
    async def _handle_choice(self, choice: str, failing_tests: List, credits_needed: int):
        """Handle the user's choice"""
        print()  # New line after choice
        
        if choice == 'y':
            # Fix all tests
            print(f"{self.colors.CYAN}Synthesizing remedy #1...{self.colors.RESET}")
            from nova.core.fixer import TestFixer
            fixer = TestFixer()
            await fixer.fix_all(failing_tests)
            
            # Deduct credits
            self.config.deduct_credits(credits_needed)
            credits_left = self.config.get_credits()
            print(f"-{credits_needed} credits • {credits_left} remaining")
            
            if credits_left <= 10:
                print(f"{self.colors.RED}{credits_left} credits remaining{self.colors.RESET}")
                
        elif choice == 'd':
            # Show diff first
            from nova.core.diff_viewer import DiffViewer
            viewer = DiffViewer()
            await viewer.show_preview(failing_tests[0])
            # Then re-prompt
            await self.show_main_prompt()
            
        elif choice == 'q':
            # Quit gracefully
            sys.exit(0)
        else:
            # Invalid choice, re-prompt
            await self.show_main_prompt() 