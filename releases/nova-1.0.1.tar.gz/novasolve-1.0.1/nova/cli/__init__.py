"""
Nova CLI - The execution layer for imagination
""" 