#!/usr/bin/env python3
"""
Nova CLI - The execution layer for imagination.
"""

import os
import sys
import time
import asyncio
from typing import Optional
from pathlib import Path

from nova.cli.onboarding import ThreeBeatOnboarding
from nova.cli.interface import NovaInterface
from nova.core.config import Config
from nova.utils.colors import Colors
from nova.utils.alignment import align_output
from rich.prompt import Prompt
from rich.console import Console

console = Console()


class NovaCLI:
    """Main CLI controller for Nova 1.0"""
    
    def __init__(self):
        self.config = Config()
        self.colors = Colors()
        self.interface = NovaInterface()
        
    async def run(self):
        """Main entry point for Nova CLI"""
        # Check if this is the first run
        if not self.config.has_completed_onboarding():
            onboarding = ThreeBeatOnboarding(self.config, self.colors)
            await onboarding.run()
            self.config.mark_onboarding_complete()
        
        # Show the main interface
        await self.interface.show_main_prompt()


async def handle_github_auth():
    """Handle GitHub authentication flow"""
    # Check if we should use backend integration
    if os.getenv("NOVA_USE_BACKEND") == "true":
        # Use backend integration
        from nova.integrations.github_backend import GitHubBackendIntegration
        github = GitHubBackendIntegration()
    else:
        # Use standard local integration
        from nova.integrations.github import GitHubIntegration
        github = GitHubIntegration()
    
    if github.is_authenticated():
        username = github.get_username()
        console.print(f"\n✅ Already authenticated as @{username or 'unknown'}")
        console.print("   [dim]Run `nova reset` to clear authentication[/dim]")
        return True
    
    # Show auth prompt
    console.print("\n[bold]🔗 Link your GitHub account[/bold]")
    console.print("   Nova needs GitHub access to create pull requests")
    console.print("   [dim]• Read repository contents[/dim]")
    console.print("   [dim]• Create branches and PRs[/dim]")
    console.print("   [dim]• Read your username[/dim]")
    
    if os.getenv("NOVA_USE_BACKEND") == "true":
        console.print("\n   [yellow]Using production backend OAuth flow[/yellow]")
    
    response = Prompt.ask("\n   Continue", choices=["y", "n"], default="y")
    
    if response.lower() == "n":
        return False
    
    # Run authentication
    return await github.authenticate()


def main():
    """Entry point for the nova command"""
    # Check for reset flag
    if len(sys.argv) > 1 and sys.argv[1] == '--reset':
        Config().reset_onboarding()
        print("Onboarding reset. Run 'nova' to start fresh.")
        return
    
    cli = NovaCLI()
    
    try:
        asyncio.run(cli.run())
    except KeyboardInterrupt:
        # Silent exit on Ctrl+C
        sys.exit(0)
    except Exception as e:
        if os.environ.get('NOVA_DEBUG'):
            raise
        # Minimal error display - production copy
        from nova.core.microcopy import MicroCopy
        print(f"\n{Colors.ERROR}{MicroCopy.ERROR_FALLBACK}{Colors.RESET}")
        sys.exit(1)


if __name__ == "__main__":
    main() 