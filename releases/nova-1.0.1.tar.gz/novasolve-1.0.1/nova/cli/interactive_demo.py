#!/usr/bin/env python3
"""
Interactive demo for Nova 1.0
Shows the complete user experience with production copy.
"""

import asyncio
import sys
import os
import time

# Add nova to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nova.cli.main import NovaCLI
from nova.utils.colors import Colors
from nova.core.microcopy import MicroCopy


async def show_user_perspective():
    """
    Show Nova 1.0 from the user's perspective with all production copy.
    """
    colors = Colors()
    
    print("\n" + "="*60)
    print("NOVA 1.0 USER EXPERIENCE DEMO")
    print("="*60)
    print("\nThis demo shows the exact user experience with production copy.")
    print("Press Enter to start...")
    input()
    
    # Clear screen for clean experience
    print("\033[2J\033[H")
    
    # 1. Initial Load Screen
    print("\n[INITIAL LOAD SCREEN]\n")
    print()  # One blank line above
    print("Nova 1.0 — The execution layer for imagination.")
    print("100 PR credits loaded • ≈60s first run")
    print()  # One blank line below
    
    await asyncio.sleep(2)
    
    # 2. Demo Phase
    print("\n[DEMO PHASE]\n")
    print("Sandbox test: fixing a failure in real time...")
    
    # Simulate progress bar
    for i in range(101):
        blocks = "▁▂▃▄▅▆▇█"
        filled = int(i / 100 * len(blocks))
        bar = ''.join(blocks[:filled]) + ' ' * (len(blocks) - filled)
        print(f"\r{bar} {i}%", end='', flush=True)
        await asyncio.sleep(0.08)
    
    print(f"\r▁▂▃▄▅▆▇█ 100% • green ✅")
    await asyncio.sleep(1)
    
    # 3. GitHub Connection
    print("\n\n[GITHUB CONNECTION]\n")
    print("Press Enter to link GitHub (@sebastianwessel)")
    input()
    print(f"{colors.SUCCESS}✓ Linked to @sebastianwessel{colors.RESET}")
    
    await asyncio.sleep(1)
    
    # 4. First Real Action
    print("\n\n[FIRST REAL ACTION]\n")
    print("Found 7 failing tests in feature/login-2fa")
    print()
    print("Cost: 7 × $5 → $35 (credits 93/100)")
    print()
    print("[Y] Fix all   [D] Diff first   [Q] Quit")
    
    # Show social proof ticker
    print(f"\n{colors.CYAN}287 tests fixed in last hour{colors.RESET}")
    
    print("\n\nPress Y to simulate fixing tests...")
    choice = input().lower()
    
    if choice == 'y':
        # 5. Fix Process
        print("\n\n[FIX PROCESS]\n")
        print(f"{colors.CYAN}Synthesizing remedy #1...{colors.RESET}")
        await asyncio.sleep(2)
        print("✅ test_auth.py::test_login fixed in 1.1s")
        
        await asyncio.sleep(1)
        print(f"{colors.CYAN}Synthesizing remedy #2...{colors.RESET}")
        await asyncio.sleep(2)
        print("✅ test_auth.py::test_2fa fixed in 1.3s")
        
        print("\n... (5 more tests fixed)")
        
        await asyncio.sleep(1)
        print(f"\n{MicroCopy.ALL_GREEN}")
        
        # 6. Post-Success
        print("\n\n[POST-SUCCESS]\n")
        print("-$35 • 65 credits")
        print(f"\n{colors.SUCCESS}You're Founding #27{colors.RESET}")
        
        # Show expiration notice
        print(f"\n\033[90mcredits expire in 30 days\033[0m")
        
        # 7. Social Proof Rotation
        print("\n\n[SOCIAL PROOF TICKER - rotates every 10s]\n")
        messages = [
            "1,042 PRs merged today",
            "17 tests being fixed now",
            "Average fix time: 47 seconds",
        ]
        for msg in messages:
            print(f"{colors.CYAN}{msg}{colors.RESET}")
            await asyncio.sleep(2)
    
    # 8. Exit State
    print("\n\n[EXIT STATE]\n")
    print("(Simple cursor blink, no glow)")
    print("_", end='', flush=True)
    await asyncio.sleep(0.5)
    print("\r ", end='', flush=True)
    await asyncio.sleep(0.5)
    print("\r_", end='', flush=True)
    
    print("\n\n" + "="*60)
    print("END OF DEMO")
    print("="*60)
    print("\nKey features demonstrated:")
    print("- Three-beat onboarding")
    print("- Transparent pricing")
    print("- Single-key actions")
    print("- Social proof")
    print("- Founding member identity")
    print("- Scarcity (expiration)")
    print("- Clean exit state")


if __name__ == "__main__":
    try:
        asyncio.run(show_user_perspective())
    except KeyboardInterrupt:
        print("\n\nDemo interrupted.")
        sys.exit(0) 