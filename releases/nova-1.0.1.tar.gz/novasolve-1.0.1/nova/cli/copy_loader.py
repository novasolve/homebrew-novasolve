"""
Copy loader for Nova CLI
Loads and formats copy from the onboarding.txt file
"""

from pathlib import Path
from typing import Dict, Optional


class CopyLoader:
    """Loads copy from the onboarding.txt file"""
    
    def __init__(self):
        self.copy_file = Path(__file__).parent / "assets" / "en-US" / "onboarding.txt"
        self._copy_cache = {}
        self._load_copy()
    
    def _load_copy(self):
        """Load all copy from the file into memory"""
        if not self.copy_file.exists():
            return
        
        content = self.copy_file.read_text()
        current_section = None
        current_content = []
        
        for line in content.split('\n'):
            # Skip comment lines
            if line.startswith('#'):
                continue
            
            # Check for section headers
            if line.strip().startswith('Beat ') and '—' in line:
                # Save previous section
                if current_section:
                    self._copy_cache[current_section] = '\n'.join(current_content).strip()
                
                # Extract beat number
                beat_num = line.split('Beat ')[1].split(' ')[0]
                current_section = f"beat_{beat_num}"
                current_content = []
            
            # Check for fallback sections
            elif line.startswith(':fallback_'):
                if current_section:
                    self._copy_cache[current_section] = '\n'.join(current_content).strip()
                
                current_section = line.strip(':')
                current_content = []
            
            # Regular content line
            elif current_section and not line.startswith('─'):
                current_content.append(line)
        
        # Save last section
        if current_section:
            self._copy_cache[current_section] = '\n'.join(current_content).strip()
    
    def get_beat(self, beat_id: str) -> str:
        """Get copy for a specific beat"""
        # Map old-style IDs to new format
        mapping = {
            "beat_1_welcome": "beat_1",
            "beat_2_demo": "beat_2",
            "beat_3_auth": "beat_3",
            "beat_4_scan": "beat_4",
            "beat_5_decision": "beat_5",
            "beat_6_preview": "beat_6",
            "beat_7_scope": "beat_7",
            "beat_8_progress": "beat_8",
            "beat_9_success": "beat_9",
            "beat_10_next": "beat_10",
            "beat_11_feedback": "beat_11",
            "beat_12_telemetry": "beat_12",
            "beat_13_share": "beat_13",
        }
        
        beat_key = mapping.get(beat_id, beat_id)
        
        # Return hardcoded copy for now
        copy_text = {
            "beat_1": """Welcome to **Nova Solve 1.0** — the AI teammate that fixes failing tests fast.
100 free credits loaded.
Goal: first green test in under 60 s.""",
            
            "beat_2": """[1/3] Analyzing demo repo …▂▃▄▅▆▇█ 100%
[2/3] Building fix       …▂▃▄▅▆▇█ 100%
[3/3] Testing            …▂▃▄▅▆▇█ 100%
✅  Demo test fixed in {seconds}s — all green.  Ready for your code next.""",
            
            "beat_3": """Press ↵ to link GitHub (read-only).  Write scope requested only when we open a PR.
(We'll pop a browser; keep this terminal open.)""",
            
            "beat_4": """Scanning **{repo_name}** in read-only mode …▂▃▄▅▆▇█
Found **{fail_count}** failing test(s).  {credits} credits remain.""",
            
            "beat_5": """How do you want to handle these failures?
[P] Preview fix   (default, safe)
[S] Solve now     (opens PR)
[C] Cancel""",
        }
        
        return copy_text.get(beat_key, self._copy_cache.get(beat_key, "")) or ""
    
    def get_fallback(self, fallback_id: str) -> str:
        """Get fallback copy"""
        fallbacks = {
            "offline": "Looks like you're offline.  Running demo in local-only mode (no GitHub needed).",
            "zero_failures": "No failing tests found.  We spun up a throw-away test in memory so you can still see Nova work (your repo unchanged).",
            "write_denied": "No worries — here's the patch diff.  Apply manually or re-run `nova solve` anytime.",
        }
        
        return fallbacks.get(fallback_id, self._copy_cache.get(f"fallback_{fallback_id}", "")) or ""
    
    def format(self, text: str, **kwargs) -> str:
        """Format copy with variables"""
        for key, value in kwargs.items():
            text = text.replace(f"{{{key}}}", str(value))
        return text 