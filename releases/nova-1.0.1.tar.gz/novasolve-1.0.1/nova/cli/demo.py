"""Nova onboarding demo - showcases fixing a failing test in under 60 seconds."""
import time
import subprocess
import sys
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


def run_email_validation_demo():
    """Run the email validation regex fix demo."""
    console.clear()
    
    # Welcome message
    console.print("\n[bold blue]🚀 Nova Demo: Fixing Failing Tests Fast[/bold blue]\n")
    console.print("Let's see Nova fix a common regex bug in [bold]under 60 seconds[/bold]...\n")
    
    time.sleep(1)
    
    # Show the failing test
    console.print(Panel("""[red]✗ FAIL[/red] test_complex_emails

The test expects these emails to be valid:
• user@mail.company.co.uk
• contact@blog.example.museum  
• support@helpdesk.company.systems

But the regex pattern is too strict!""", 
        title="[red]Failing Test[/red]", 
        border_style="red"))
    
    time.sleep(2)
    
    # Show Nova analyzing
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Nova is analyzing the test failure...", total=None)
        time.sleep(2)
        progress.update(task, description="[green]Nova found the issue!")
    
    # Show the fix
    console.print("\n[bold green]✨ Nova's Fix:[/bold green]")
    
    diff_text = """--- src/validation.py
+++ src/validation.py
@@ -12,7 +12,8 @@ def validate_email(email: str) -> bool:
     # Bug: Only allows TLDs of 2-4 characters, missing support for subdomains
-    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,4}$'
+    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$'
+    # Fixed: Now handles multiple subdomains and longer TLDs"""
    
    syntax = Syntax(diff_text, "diff", theme="monokai", line_numbers=False)
    console.print(Panel(syntax, border_style="green"))
    
    time.sleep(2)
    
    # Show the result
    console.print("\n[bold green]✅ All Tests Pass![/bold green]")
    console.print("""
The fix allows:
• Multiple subdomain levels (mail.company.co.uk)
• Longer TLDs (.museum, .systems)
• While still rejecting invalid emails

[dim]Nova understood the test's intent and crafted an intelligent fix![/dim]
""")
    
    # Show time taken
    console.print(f"\n⏱️  [bold]Total time: 12 seconds[/bold]")
    console.print("\n[bold cyan]This is what Nova does for YOUR failing tests![/bold cyan]\n")


def run_full_demo():
    """Run the complete onboarding demo flow."""
    try:
        # First, run our showcase demo
        run_email_validation_demo()
        
        # Pause before continuing
        console.print("\n[dim]Press ENTER to continue to GitHub setup...[/dim]")
        input()
        
        # Now guide to GitHub connection
        console.clear()
        console.print(Panel("""[bold]🔗 Connect Nova to Your GitHub[/bold]

Nova will now help you:
1. Connect to your GitHub account
2. Find repositories with failing tests
3. Create real pull requests with fixes

Ready to fix your actual failing tests?""", 
            title="[bold blue]Next Step[/bold blue]",
            border_style="blue"))
        
        return True
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Demo cancelled.[/yellow]")
        return False
    except Exception as e:
        console.print(f"\n[red]Demo error: {e}[/red]")
        return False


if __name__ == "__main__":
    run_full_demo() 