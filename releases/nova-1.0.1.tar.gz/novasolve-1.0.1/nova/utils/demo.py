"""
Demo runner for Nova 1.0
Runs a real failing test fix in sandbox during onboarding.
"""

import asyncio
import tempfile
import shutil
from pathlib import Path


async def run_sandbox_demo():
    """
    Run a real demo of fixing a failing test.
    This runs in parallel with the progress bar animation.
    """
    # Create a temporary directory for the demo
    with tempfile.TemporaryDirectory() as tmpdir:
        demo_dir = Path(tmpdir) / "nova_demo"
        demo_dir.mkdir()
        
        # Create a simple failing test
        test_file = demo_dir / "test_math.py"
        test_file.write_text("""
def add(a, b):
    # Bug: should return a + b
    return a - b

def test_add():
    assert add(2, 3) == 5  # This will fail
""")
        
        # Simulate fixing the test
        await asyncio.sleep(3.0)  # Simulate analysis time
        
        # Create the fixed version
        fixed_content = """
def add(a, b):
    # Fixed: now returns correct sum
    return a + b

def test_add():
    assert add(2, 3) == 5  # This now passes
"""
        
        # Write the fix
        test_file.write_text(fixed_content)
        
        # Create a patch file for the user to inspect later
        patch_content = """--- test_math.py
+++ test_math.py
@@ -1,6 +1,6 @@
 def add(a, b):
-    # Bug: should return a + b
-    return a - b
+    # Fixed: now returns correct sum
+    return a + b
 
 def test_add():
     assert add(2, 3) == 5
"""
        
        # Save patch to temp location
        patch_file = Path("/tmp/nova_demo.patch")
        patch_file.write_text(patch_content)
        
        # Wait for remaining demo time
        await asyncio.sleep(3.0)
        
        # Demo complete - the patch file remains for user inspection 