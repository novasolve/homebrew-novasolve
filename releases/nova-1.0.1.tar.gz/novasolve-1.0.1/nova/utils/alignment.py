"""
Alignment utilities for Nova 1.0
Ensures every colon aligns in live output across 80-col terminals.
"""

from typing import List, Tuple, Optional
import re


def align_output(lines: List[str], separator: str = ':', terminal_width: int = 80) -> List[str]:
    """
    Align output lines by a separator character.
    Ensures consistent alignment across all lines.
    """
    if not lines:
        return lines
    
    # Find the maximum position of the separator
    max_pos = 0
    for line in lines:
        if separator in line:
            pos = line.find(separator)
            max_pos = max(max_pos, pos)
    
    # Align all lines
    aligned = []
    for line in lines:
        if separator in line:
            parts = line.split(separator, 1)
            left = parts[0].ljust(max_pos)
            aligned.append(f"{left}{separator}{parts[1]}")
        else:
            aligned.append(line)
    
    return aligned


def format_table(rows: List[List[str]], headers: Optional[List[str]] = None) -> List[str]:
    """
    Format data as an aligned table.
    Used for displaying structured information.
    """
    if not rows:
        return []
    
    # Calculate column widths
    all_rows = [headers] if headers else []
    all_rows.extend(rows)
    
    col_widths = []
    for col_idx in range(len(all_rows[0])):
        max_width = max(len(str(row[col_idx])) for row in all_rows)
        col_widths.append(max_width)
    
    # Format lines
    lines = []
    
    # Add headers if provided
    if headers:
        header_parts = []
        for i, header in enumerate(headers):
            header_parts.append(str(header).ljust(col_widths[i]))
        lines.append('  '.join(header_parts))
        
        # Add separator
        sep_parts = []
        for width in col_widths:
            sep_parts.append('-' * width)
        lines.append('  '.join(sep_parts))
    
    # Add data rows
    for row in rows:
        row_parts = []
        for i, cell in enumerate(row):
            row_parts.append(str(cell).ljust(col_widths[i]))
        lines.append('  '.join(row_parts))
    
    return lines


def measure_display_width(text: str) -> int:
    """
    Measure the actual display width of text, accounting for ANSI codes.
    """
    # Remove ANSI escape sequences
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    clean_text = ansi_escape.sub('', text)
    
    # Count actual characters (basic implementation)
    # Could be enhanced to handle unicode width properly
    return len(clean_text) 