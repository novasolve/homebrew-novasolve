"""
Progress indicators for Nova CLI
"""

import sys
import time
from typing import Optional


class AnimatedProgress:
    """Simple animated progress indicator"""
    
    def __init__(self):
        self.blocks = "▂▃▄▅▆▇█"
        self.current = 0
    
    def show(self, progress: float, prefix: str = ""):
        """Show progress bar with given percentage (0.0 to 1.0)"""
        filled = int(progress * len(self.blocks))
        if filled < len(self.blocks):
            bar = self.blocks[:filled + 1]
            else:
            bar = self.blocks
        
        output = f"\r{prefix}{bar}"
        print(output, end='', flush=True)
    
    def clear(self):
        """Clear the progress bar"""
        print("\r" + " " * 80 + "\r", end='', flush=True) 