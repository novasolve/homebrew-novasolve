"""
Pricing engine for Nova 1.0
Simple, transparent pricing: $5 per test.
"""


class PricingEngine:
    """Handle pricing calculations for Nova"""
    
    # Fixed price per test as specified
    PRICE_PER_TEST = 5  # USD
    
    def calculate_cost(self, test_count: int) -> int:
        """Calculate the cost for fixing N tests"""
        return test_count * self.PRICE_PER_TEST
    
    def get_price_per_test(self) -> int:
        """Get the price per test"""
        return self.PRICE_PER_TEST 