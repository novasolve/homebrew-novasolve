"""
Configuration management for Nova 1.0
Handles credits, onboarding state, and user preferences.
"""

import os
import json
from pathlib import Path
from typing import Optional
import subprocess


class Config:
    """Minimal configuration for Nova 1.0"""
    
    def __init__(self):
        # Config directory in user's home
        self.config_dir = Path.home() / '.nova'
        self.config_file = self.config_dir / 'config.json'
        
        # Ensure config directory exists
        self.config_dir.mkdir(exist_ok=True)
        
        # Load or initialize config
        self._config = self._load_config()
        
    def _load_config(self) -> dict:
        """Load config from file or create default"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return json.load(f)
        
        # Default config for new users
        return {
            'credits': 100,  # 100 PR credits as gift
            'onboarding_complete': False,
            'github_connected': False,
            'github_username': None,
            'founding_number': None,
            'first_run_timestamp': None,
        }
    
    def _save_config(self):
        """Save config to file"""
        with open(self.config_file, 'w') as f:
            json.dump(self._config, f, indent=2)
    
    def has_completed_onboarding(self) -> bool:
        """Check if user has completed onboarding"""
        return self._config.get('onboarding_complete', False)
    
    def mark_onboarding_complete(self):
        """Mark onboarding as complete"""
        self._config['onboarding_complete'] = True
        if not self._config.get('first_run_timestamp'):
            import time
            self._config['first_run_timestamp'] = time.time()
        self._save_config()
    
    def get_github_username(self) -> Optional[str]:
        """Get GitHub username from git config or stored value"""
        if self._config.get('github_username'):
            return self._config['github_username']
            
        # Try to get from git config
        try:
            result = subprocess.run(
                ['git', 'config', 'user.name'],
                capture_output=True,
                text=True,
                timeout=1
            )
            if result.returncode == 0 and result.stdout.strip():
                username = result.stdout.strip()
                self._config['github_username'] = username
                self._save_config()
                return username
        except:
            pass
            
        return None
    
    def set_github_connected(self, connected: bool):
        """Mark GitHub as connected"""
        self._config['github_connected'] = connected
        self._save_config()
    
    def get_credits(self) -> int:
        """Get current credit balance"""
        return self._config.get('credits', 0)
    
    def deduct_credits(self, amount: int):
        """Deduct credits from balance"""
        current = self.get_credits()
        self._config['credits'] = max(0, current - amount)
        self._save_config()
    
    def add_credits(self, amount: int):
        """Add credits to balance"""
        self._config['credits'] = self.get_credits() + amount
        self._save_config()
    
    def set_founding_number(self, number: int):
        """Set the user's founding member number"""
        if not self._config.get('founding_number'):
            self._config['founding_number'] = number
            self._save_config()
    
    def reset_onboarding(self):
        """Reset onboarding status for fresh start"""
        self._config['onboarding_complete'] = False
        self._config['github_connected'] = False
        if 'first_run_timestamp' in self._config:
            del self._config['first_run_timestamp']
        self._save_config() 