"""
Diff viewer for Nova 1.0
Shows preview of fixes before applying them
"""

from typing import Dict, Any
from nova.utils.colors import Colors
from nova.core.fixer import TestFixer


class DiffViewer:
    """Preview fixes before applying them"""
    
    def __init__(self):
        self.colors = Colors()
        self.fixer = TestFixer()
        
    async def show_preview(self, test_info: Dict[str, Any]):
        """Show a preview of the fix for a test"""
        print(f"\n{self.colors.CYAN}Generating fix preview for {test_info['name']}...{self.colors.RESET}\n")
        
        # Generate the fix
        fix_result = await self.fixer.fix_single_test(test_info)
        
        if fix_result.get('success') and 'diff' in fix_result:
            # Show the diff
            self._display_diff(fix_result['diff'])
        else:
            print(f"{self.colors.RED}Could not generate fix preview{self.colors.RESET}")
    
    def _display_diff(self, diff: str):
        """Display a colored diff"""
        if not diff:
            print("No changes needed")
            return
        
        lines = diff.split('\n')
        for line in lines:
            if line.startswith('+++'):
                print(f"{self.colors.CYAN}{line}{self.colors.RESET}")
            elif line.startswith('---'):
                print(f"{self.colors.CYAN}{line}{self.colors.RESET}")
            elif line.startswith('+'):
                print(f"{self.colors.GREEN}{line}{self.colors.RESET}")
            elif line.startswith('-'):
                print(f"{self.colors.RED}{line}{self.colors.RESET}")
            elif line.startswith('@@'):
                print(f"{self.colors.CYAN}{line}{self.colors.RESET}")
            else:
                print(line) 