"""
Test finder for Nova 1.0
Finds failing tests in the current repository
"""

import asyncio
import subprocess
import json
from pathlib import Path
from typing import List, Dict, Any, Optional


class TestFinder:
    """Find failing tests in a repository"""
    
    def __init__(self):
        self.test_patterns = ["test_*.py", "*_test.py"]
    
    async def find_failing_tests(self, test_dir: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Find all failing tests in the repository.
        Returns a list of test information dictionaries.
        """
        # For demo, check if we're in the nova-1.0 directory with demo_repo
        cwd = Path.cwd()
        if cwd.name == "nova-1.0" and (cwd / "demo_repo" / "tests").exists():
            # Run pytest on demo_repo
            return await self._run_pytest(str(cwd / "demo_repo"))
        
        # Otherwise try to find tests in current directory
        test_path = test_dir or "."
        if Path(test_path).exists():
            return await self._run_pytest(test_path)
        
        # Return empty list if no tests found
        return []
    
    async def _run_pytest(self, test_path: str) -> List[Dict[str, Any]]:
        """Run pytest and parse the results"""
        try:
            # Run pytest with JSON output
            result = await asyncio.create_subprocess_exec(
                "python3", "-m", "pytest", test_path, 
                "--tb=short", "-v", "--json-report", "--json-report-file=/tmp/pytest_report.json",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await result.communicate()
            
            # Try to read the JSON report
            try:
                with open("/tmp/pytest_report.json", "r") as f:
                    report = json.load(f)
                    return self._parse_json_report(report)
            except:
                # Fallback to parsing stdout
                return self._parse_pytest_output(stdout.decode() + stderr.decode())
                
        except Exception as e:
            # If pytest fails, try basic parsing
            try:
                result = subprocess.run(
                    ["python3", "-m", "pytest", test_path, "--tb=short", "-v"],
                    capture_output=True,
                    text=True
                )
                return self._parse_pytest_output(result.stdout + result.stderr)
            except:
                # Return mock data if all else fails
                return self._get_mock_failures()
    
    def _parse_json_report(self, report: Dict) -> List[Dict[str, Any]]:
        """Parse pytest JSON report"""
        failures = []
        
        for test in report.get("tests", []):
            if test.get("outcome") == "failed":
                failures.append({
                    "file": test.get("nodeid", "").split("::")[0],
                    "name": test.get("nodeid", "").split("::")[-1],
                    "error": test.get("call", {}).get("longrepr", "Test failed"),
                    "line": test.get("lineno", 0)
                })
        
        return failures
    
    def _parse_pytest_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse pytest text output"""
        failures = []
        lines = output.split('\n')
        
        for i, line in enumerate(lines):
            if 'FAILED' in line and '::' in line:
                # Extract test file and name
                parts = line.split('::')
                if len(parts) >= 2:
                    test_file = parts[0].strip()
                    if ' ' in test_file:
                        test_file = test_file.split()[-1]
                    test_name = parts[1].split()[0].split('[')[0]  # Remove any parametrization
                    
                    # Look for error details
                    error = "Test failed"
                    for j in range(i+1, min(i+10, len(lines))):
                        if 'AssertionError' in lines[j]:
                            error = lines[j].strip()
                            break
                        elif 'Error:' in lines[j]:
                            error = lines[j].strip()
                            break
                    
                    failures.append({
                        'file': test_file,
                        'name': test_name,
                        'error': error,
                        'line': 0
                    })
        
        return failures if failures else self._get_mock_failures()
    
    def _get_mock_failures(self) -> List[Dict[str, Any]]:
        """Return mock failures for demo purposes"""
        return [
            {
                'file': 'demo_repo/tests/test_auth.py',
                'name': 'test_login',
                'error': 'AssertionError: assert False == True',
                'line': 12
            },
            {
                'file': 'demo_repo/tests/test_auth.py', 
                'name': 'test_2fa',
                'error': 'AssertionError: assert 6 == 4',
                'line': 20
            },
            {
                'file': 'demo_repo/tests/test_auth.py',
                'name': 'test_password_reset',
                'error': "KeyError: 'reset_token'",
                'line': 29
            }
        ]
    
    def get_test_location(self, failing_tests: List[Dict[str, Any]]) -> str:
        """Get a description of where the tests are located"""
        if not failing_tests:
            return "current directory"
        
        # Get the common directory
        files = [t['file'] for t in failing_tests]
        if files:
            # Find common prefix
            common = Path(files[0]).parent
            for f in files[1:]:
                f_parent = Path(f).parent
                while common not in f_parent.parents and common != f_parent:
                    common = common.parent
            
            return str(common) if common != Path(".") else "current directory"
        
        return "current directory" 