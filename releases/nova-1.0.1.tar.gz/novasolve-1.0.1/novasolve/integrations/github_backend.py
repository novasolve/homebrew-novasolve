"""
GitHub Backend Integration for Nova 1.0
Uses the production backend at api.joinnova.com
"""

import os
import json
import time
import secrets
import webbrowser
from pathlib import Path
from typing import Optional, Dict, Any
from urllib.parse import urlencode

# Backend configuration
BACKEND_URL = os.getenv("NOVA_BACKEND_URL", "https://api.joinnova.com")
GITHUB_CLIENT_ID = os.getenv("GITHUB_CLIENT_ID", "Iv23liiZaWy61CvjQQdz")

# Local storage for auth state
CONFIG_DIR = Path.home() / ".nova"
CONFIG_DIR.mkdir(exist_ok=True)
STATE_FILE = CONFIG_DIR / "backend_auth_state.json"
AUTH_FILE = CONFIG_DIR / "backend_auth.json"


class GitHubBackendIntegration:
    """GitHub integration using the production backend OAuth flow"""
    
    def __init__(self):
        self.backend_url = BACKEND_URL
        self.client_id = GITHUB_CLIENT_ID
        
        # Use existing Nova config directory
        self.config_dir = CONFIG_DIR
        self.token_file = CONFIG_DIR / "github_token.json"
        
        # For backend auth state tracking
        self.state_file = STATE_FILE
        self.auth_file = AUTH_FILE
        
    def is_authenticated(self) -> bool:
        """Check if we have valid GitHub authentication"""
        # Check local token file (Nova's standard location)
        if self.token_file.exists():
            try:
                data = json.loads(self.token_file.read_text())
                return bool(data.get('access_token') or data.get('authenticated'))
            except:
                pass
        return False
    
    def get_username(self) -> Optional[str]:
        """Get authenticated GitHub username"""
        if self.token_file.exists():
            try:
                data = json.loads(self.token_file.read_text())
                return data.get('username')
            except:
                pass
        return None
    
    async def authenticate(self) -> bool:
        """Run GitHub authentication through the backend"""
        print("\n🔐 Starting GitHub authentication...")
        print("   Using production backend OAuth flow")
        
        # Generate state for backend
        timestamp = int(time.time())
        # Use NOVA_CLI as a special identifier for CLI users
        state = f"NOVA_CLI:cli_auth:{timestamp}"
        
        # Save state for tracking
        auth_state = {
            "state": state,
            "started_at": timestamp,
            "backend_url": self.backend_url
        }
        self.state_file.write_text(json.dumps(auth_state, indent=2))
        
        # Build OAuth URL using backend callback
        oauth_params = {
            "client_id": self.client_id,
            "redirect_uri": f"{self.backend_url}/github/callback",
            "scope": "repo write:org read:user",
            "state": state
        }
        oauth_url = f"https://github.com/login/oauth/authorize?{urlencode(oauth_params)}"
        
        print(f"📱 Opening browser for GitHub authorization...")
        print(f"   If browser doesn't open, visit: {oauth_url}")
        
        # Open browser
        webbrowser.open(oauth_url)
        
        print("\n⏳ Complete the authorization in your browser")
        print("   You'll see a success page at api.joinnova.com")
        print("")
        print("After authorizing, you'll need to:")
        print("1. Copy your GitHub username from the success page")
        print("2. Return here and enter it")
        print("")
        
        # Manual completion for now (until we add API)
        github_username = input("Enter your GitHub username after authorizing: ").strip()
        
        if github_username:
            # Mark as authenticated
            # In a full implementation, we'd query the backend API
            auth_data = {
                'authenticated': True,
                'username': github_username,
                'access_token': 'backend_managed',  # Token is managed by backend
                'authenticated_at': time.time(),
                'backend_url': self.backend_url,
                'state': state
            }
            
            # Save to Nova's expected location
            self.token_file.write_text(json.dumps(auth_data, indent=2))
            
            # Also save backend auth info
            self.auth_file.write_text(json.dumps(auth_data, indent=2))
            
            print(f"\n✅ Authenticated as @{github_username}")
            print("   Authentication managed by production backend")
            return True
        
        print("\n❌ Authentication cancelled")
        return False
    
    def get_stored_installation(self) -> Optional[Dict[str, Any]]:
        """Get stored GitHub installation data (for compatibility)"""
        if self.token_file.exists():
            try:
                return json.loads(self.token_file.read_text())
            except:
                pass
        return None
    
    def store_installation(self, data: Dict[str, Any]):
        """Store GitHub installation data (for compatibility)"""
        self.token_file.write_text(json.dumps(data, indent=2)) 