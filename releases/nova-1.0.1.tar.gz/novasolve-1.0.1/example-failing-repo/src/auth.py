"""Authentication utilities."""

def check_password_strength(password):
    """Check if a password meets security requirements."""
    # Requirements:
    # - At least 8 characters
    # - Contains uppercase and lowercase
    # - Contains at least one number
    # - Contains at least one special character
    
    if len(password) < 8:
        return False
    
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    
    # Bug: checking for special chars incorrectly
    special_chars = "!@#$%^&*()"
    has_special = any(c in special_chars for c in password)
    
    # Bug: using OR instead of AND
    return has_upper or has_lower or has_digit or has_special 