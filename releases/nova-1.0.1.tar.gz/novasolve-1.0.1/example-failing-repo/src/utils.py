"""Utility functions for the project."""

import re

def validate_email(email):
    """Validate an email address."""
    # Bug: regex doesn't handle subdomains properly
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$'
    return bool(re.match(pattern, email))

def format_phone(phone):
    """Format a phone number."""
    # Remove all non-digits
    digits = re.sub(r'\D', '', phone)
    
    if len(digits) == 10:
        return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
    return phone 