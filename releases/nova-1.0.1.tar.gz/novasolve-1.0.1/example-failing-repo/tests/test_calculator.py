"""Tests for calculator module."""

import pytest
from src.calculator import add, multiply, divide

def test_addition():
    """Test addition function."""
    # This will fail because add() has a bug
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    assert add(0, 0) == 0

def test_multiplication():
    """Test multiplication function."""
    assert multiply(2, 3) == 6
    assert multiply(-2, 3) == -6
    assert multiply(0, 5) == 0

def test_division():
    """Test division function."""
    assert divide(10, 2) == 5
    assert divide(-10, 2) == -5
    
    with pytest.raises(ValueError):
        divide(10, 0) 