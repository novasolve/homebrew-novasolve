"""Tests for authentication utilities."""

from src.auth import check_password_strength

def test_password_strength():
    """Test password strength validation."""
    # Should pass - strong password
    assert check_password_strength("Str0ng!Pass") == True
    
    # Should fail - too short
    assert check_password_strength("Sh0rt!") == False
    
    # These will fail due to the OR bug instead of AND
    # Should fail - only lowercase
    assert check_password_strength("weakpassword123!") == False
    
    # Should fail - no special chars
    assert check_password_strength("Password123") == False
    
    # Should fail - no numbers
    assert check_password_strength("Password!") == False
    
    # Should fail - no uppercase
    assert check_password_strength("password123!") == False 