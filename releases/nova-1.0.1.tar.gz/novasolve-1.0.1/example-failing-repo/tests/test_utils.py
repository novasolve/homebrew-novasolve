"""Tests for utility functions."""

from src.utils import validate_email, format_phone

def test_email_validation():
    """Test email validation function."""
    # Basic emails
    assert validate_email("user@example.com") == True
    assert validate_email("test.user@example.com") == True
    
    # This will fail - subdomain email
    assert validate_email("user@mail.example.com") == True
    
    # This will fail - long TLD
    assert validate_email("user@example.technology") == True
    
    # Invalid emails
    assert validate_email("not-an-email") == False
    assert validate_email("@example.com") == False
    assert validate_email("user@") == False

def test_phone_formatting():
    """Test phone number formatting."""
    assert format_phone("1234567890") == "(123) 456-7890"
    assert format_phone("123-456-7890") == "(123) 456-7890"
    assert format_phone("(123) 456-7890") == "(123) 456-7890"
    assert format_phone("123.456.7890") == "(123) 456-7890"
    
    # Invalid phone numbers
    assert format_phone("12345") == "12345"
    assert format_phone("12345678901") == "12345678901" 